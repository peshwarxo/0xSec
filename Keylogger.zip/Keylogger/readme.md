🛡️ Basic Python Keylogger (For Education Only)

This is a lightweight keylogger built with Python for educational and ethical hacking simulations.

🔧 Features
- Captures all keypresses using `pynput`
- Saves logs to timestamped text files
- Useful for red teaming, awareness, or detection training

⚠️ Ethical Disclaimer
This tool is for **educational use only**. Do not deploy it without **explicit consent** or in unauthorized environments.

📦 Requirements
bash
pip install pynput
